import React, { useState, useEffect } from "react";
import CharacterList from "./components/characterlist";
import "tachyons";
import SearchBox from "./components/searchbox";


function App() {
    const [ characters, setCharacters ] = useState([]);
    const [ nextURL, setNextURL ] = useState("https://rickandmortyapi.com/api/character/");
    const [ searchfield, setSearchField ] = useState("");
    const [ filteredCharacters, setFilteredCharacters ] = useState([]);

    useEffect(() => {
       if(nextURL != null) {
        fetch(nextURL)
        .then(response => response.json())
        .then((result) => {
            setCharacters(characters.concat(result["results"]));
            setNextURL(result["info"]["next"])
        });
       } else {
            setFilteredCharacters(characters);
       }
    }, [nextURL])

    const onSearchChange = (event) => {
        setSearchField( event.target.value )
    }

    useEffect(() => {
        setFilteredCharacters(characters.filter((character) => {
            return character.name.toLowerCase().includes(searchfield.toLocaleLowerCase())
        }));
    }, [searchfield])


    
    return (
        <div className="tc">
            <h1 className="f1">Characters</h1>
            <SearchBox searchChange={onSearchChange}/>
            <CharacterList characters = {filteredCharacters} />
        </div>
    )
}

export default App;
