import React, { startTransition } from "react";
import Character from "./character";
import "tachyons";

const CharacterList = ({characters}) => {
    return (
        <div className="tc">
            {" "}
            {characters.map((character) => {
                return (
                    <Character
                        key = {character.id}
                        name = {character.name}
                        status = {character.status}
                        id = {character.id}
                        image = {character.image}
                        species = {character.species}
                    />
                );
            })}
        </div>
    );
};

export default CharacterList;