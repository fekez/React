import React from "react";
import "tachyons"


const Character = ({ id, name, status, image, species}) => {
    return (
        <article className="bg-mid-gray dit mw5 ba b--black-10 mv3 ma2 grow">
            <div>
                <img className="w5 h5 db " src={image} alt={name} />
            </div>
            <div className="w5 h4">
                <div className="tc">
                    <h2 className="f3 mb2" >{name}</h2>
                </div>
                <div>
                    <h4 className="f5 fw4 mt0">
                        <div className={ status == "Dead" ? 
                                            "f4 bg-red h1 w1 mr3 dib br3" : 
                                            "f4 bg-green h1 w1 mr3 dib br3"}></div>
                        {status} - {species}   
                    </h4>
                </div>
            </div>
        </article>
    );
};

export default Character;

/*
return (
        <div className="character tc bg-mid-gray dib br3 pa0 ma2 grow nowrap">
            <div className="image db br2">
                <img 
                    className="h5 w5"
                    src={image}
                    alt={"Character"}
                />{" "}
            </div>
            <div className="details db h5 w5 v-top pa2 tl">
                <div className="name">
                    <p className="f3 dim lh-title">{characterName}</p>
                </div>
                <div className="status">
                <p>
                    <div className={ status == "Dead" ? 
                                        "f4 bg-red h1 w1 mr3 dib br3" : 
                                        "f4 bg-green h1 w1 mr3 dib br3"}></div>
                    {status} - {species}   
                </p>{" "}
                </div>
            </div>{" "}
        </div>
    );*/