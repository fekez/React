import React from 'react';
import ReactDOM from 'react-dom/client';
import Content from './components/Content';
import Footer from './components/Footer';
import Header from './components/Header';


const header = ReactDOM.createRoot(document.getElementById('header'));
header.render(<Header/>);

const root = ReactDOM.createRoot(document.getElementById('content'));
root.render(<Content/>);

const footer = ReactDOM.createRoot(document.getElementById('footer'));
footer.render(<Footer/>);