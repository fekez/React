import React from "react";

const Icon = ({name, imagepath, data}) => {
    return (
        <a className="link white-60 bg-transparent hover-white inline-flex items-center ma2 tc br2 pa2"
            href={data}
            title={name}>
            <svg className="dib h2 w2"
                fill="currentColor"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 16 16"
                fillRule="evenodd"
                clipRule="evenodd"
                strokeLinejoin="round"
                strokeMiterlimit="1.414">
                <path d={imagepath}
                    fillRule="nonzero" />
            </svg>
            <span className="f6 ml3 pr2">{name}</span>
        </a>
    );
};

export default Icon;