import React from "react";
import Project from "./project";

const ProjectList = ({projects}) => {
    return (
        <div className="tc">
            {" "}
            {projects.map((project) => {
                return (
                    <Project
                        key = {project.id}
                        name = {project.name}
                        image = {project.image}
                        link = {project.link}
                    />
                );
            })}
        </div>
    );
};

export default ProjectList;