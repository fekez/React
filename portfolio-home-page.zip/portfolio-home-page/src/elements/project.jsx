import React from "react";


const Project = ({ name, image, link }) => {
    return (
        <a href={link} target="_blank">
            <article className="black dit mw5 ba b--black-40 br2 mv3 ma2 grow">
                <div className="pa2">
                    <img className="w5 h4 db " src={image} alt={name} />
                </div>
                <div className="pa2">
                    <div className="tc">
                        <h4 className="f5 mb2" >{name}</h4>
                    </div>
                </div>
            </article>
        </a>
    );
}

export default Project;