import React from "react";


const HeaderItem = ({ name, link }) => {
    return (
        <a className="f6 fw4 hover-white no-underline white-70 dn dib-ns pv2 ph3 ba br2 mh2" href={link}>{name}</a>
    );
}

export default HeaderItem;