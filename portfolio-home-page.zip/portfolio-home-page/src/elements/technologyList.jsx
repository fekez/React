import React, { startTransition } from "react";
import Technology from "./technology";

const TechnologyList = ({technologies}) => {
    return (
        <div className="tc">
            {" "}
            {technologies.map((technology) => {
                return (
                    <Technology
                        key = {technology.id}
                        name = {technology.name}
                        image = {technology.image}
                    />
                );
            })}
        </div>
    );
};

export default TechnologyList;