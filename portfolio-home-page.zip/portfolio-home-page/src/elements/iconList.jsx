import React from "react";
import Icon from "./icon";

const IconList = ({ icons }) => {
    const iconComponents = icons.map((icon) => {
        return (
            <Icon
                key = {icon.id}
                data = {icon.data}
                imagepath = {icon.imagepath}
                name = {icon.name}
            />
        )
    });

    return (
        <div>
            {iconComponents}
        </div>
    );
}

export default IconList;