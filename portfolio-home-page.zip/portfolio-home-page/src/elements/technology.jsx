import React from "react";


const Technology = ({ name, image}) => {
    return (
        <article className="white bg-white-20 dit mw5 ba b--black-40 br2 mv3 ma2 grow">
            <div className="pa2">
                <img className="w4 h4 db " src={image} alt={name} />
            </div>
            <div className="pa2">
                <div className="tc">
                    <h4 className="f5 mb2" >{name}</h4>
                </div>
            </div>
        </article>
    );
};

export default Technology;