import React from "react";
import HeaderItem from "./headeritem";

const HeaderItemList = ({headers}) => {
    return (
        <div className="dtc v-mid tr pa3">
            {" "}
            {headers.map((header) => {
                return (
                    <HeaderItem
                        key = {header.id}
                        name = {header.name}
                        link = {header.link}
                    />
                );
            })}
        </div>
    );
};

export default HeaderItemList;