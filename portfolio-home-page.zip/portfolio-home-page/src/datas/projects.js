export const projects = [
    {
        id: 1,
        name: "Rick and Morty API",
        image: require("../images/rick-and-morty-api.png"),
        link: ""
    },
    {
        id: 2,
        name: "BáZol",
        image: require("../images/bazol.png"),
        link: "http://bazol.nhely.hu/"
    }
]