export const headers = [
    {
        id: 1,
        name: "Rólam",
        link: "/#from-me"
    },
    {
        id: 2,
        name: "Technológiák",
        link: "/#technologies"
    },
    {
        id: 3,
        name: "Projektek",
        link: "/#projects"
    },
    {
        id: 4,
        name: "Elérhetőségek",
        link: "/#footer"
    },
]