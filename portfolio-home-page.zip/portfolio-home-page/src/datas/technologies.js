export const technologies = [
    {
        id: 1,
        name: "HTML5",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg"
    },
    {
        id: 2,
        name: "CSS",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg"
    },
    {
        id: 3,
        name: "JavaScript",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg"
    },
    {
        id: 4,
        name: "jQuery",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/jquery/jquery-original.svg"
    },
    {
        id: 5,
        name: "PHP",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg"
    },
    {
        id: 6,
        name: "React",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg"
    },
    {
        id: 7,
        name: "Laravel",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/laravel/laravel-plain.svg"
    },
    {
        id: 8,
        name: "C++",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg"
    },
    {
        id: 9,
        name: "C#",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg"
    },
    {
        id: 10,
        name: "Unity",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/unity/unity-original.svg"
    },
    {
        id: 11,
        name: "Java",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg"
    },
    {
        id: 12,
        name: "AndroidStudio",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/androidstudio/androidstudio-original.svg"
    },
    {
        id: 13,
        name: "Swift",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/swift/swift-original.svg"
    },
    {
        id: 14,
        name: ".NET",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/dotnetcore/dotnetcore-original.svg"
    },
    {
        id: 15,
        name: "GitHub",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/github/github-original.svg"
    },
    {
        id: 16,
        name: "Git",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg"
    },
    {
        id: 17,
        name: "GitLab",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/gitlab/gitlab-original.svg"
    },
    {
        id: 18,
        name: "MySql",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg"
    },
    {
        id: 19,
        name: "SQLite",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/sqlite/sqlite-original.svg"
    },
    {
        id: 20,
        name: "Bash",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bash/bash-original.svg"
    },
    {
        id: 21,
        name: "BootStrap",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg"
    },
    {
        id: 22,
        name: "SourceTree",
        image: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/sourcetree/sourcetree-original.svg"
    }
]