function Welcome() {
    return (
        <article className="white">
            <div id="home-picture-div" className="vh-100 dt w-100 tc bg-dark-gray cover">
                <div className="dtc v-mid">
                    <h1 className="f1 f-headline-l fw1 i">Fekete Zoltán</h1>
                    <blockquote className="ph0 mh0 measure f4 lh-copy center">
                        <h3>7. féléves levelezős Mérnökinformatikus hallgató</h3>
                        <h5>Mobil és webfejlesztés specializáció</h5>
                    </blockquote>
                </div>
            </div>
        </article>
    );
}

export default Welcome;