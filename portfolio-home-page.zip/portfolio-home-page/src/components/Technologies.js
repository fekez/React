import TechnologyList from "../elements/technologyList";
import {technologies} from "../datas/technologies";

function Technologies() {
    return (
        <div id="technologies" className="tc white bg-black-80 w-100 ph5 pv5">
            <div className="w-100 mb4">
                <h2 className="white bg-white-20 br2 pa2 ph3 dib ma0 ">AZ EGYETEM ALATT MEGISMERT TECHNOLÓGIÁK</h2>
            </div>
            <TechnologyList technologies={technologies} />
        </div>
    );
}

export default Technologies;