import IconList from "../elements/iconList";
import { contacts } from "../datas/contacts";

function Footer() {
  return (
    <div className="tc w-100 ph3 pv4 bg-black-90">
      <IconList icons={contacts} />
    </div>
  );
}

export default Footer;
