function FromMe() {
    return (
        <div id="from-me" className="tc black w-100 pv5">
            <div className="w-100 mb4">
                <h2 className="white bg-black-80 br2 pa2 ph3 dib ma0 ">RÓLAM</h2>
            </div>
            <div className="mh4 tl">
                <div className="tr pa3 ph2 dib w-30">
                    <img className="w-auto-ns h-auto-ns pr5" src={require("../images/me.png")} alt="me"></img>
                </div>
                <div className="pv3 dib w-70 v-top">
                    <p className="tj pr5">A nevem Fekete Zoltán és levelezős Mérnökinformatikus hallgató vagyok. 
                        Ősszel kezdem a 7. félévemet levelező tagozaton a Neumann János Egyetem GAMF karán, 
                        melynél már csak a szakdolgozatom van hátra. Specializációm a Mobil és Webfejlesztés,
                        melyekből a webfejlesztés áll közelebb hozzám.<br/>
                        A jelenlegi munkahelyem nem kapcsolódik tanulmányaimhoz, ezért célom a váltás, 
                        a Fejlesztésben való elhelyezkedés. Programozni az egyetem előtt is tanultam az emelt szintű
                        informatika érettségimhez (Pascal), majd később a C és C++ nyelveket ismertem meg.
                        A jelenlegi tanulmányaim alatt megismert nyelveket és fejlesztői környezeteket a menüsor "Technológiák"
                        pontra kattintva találja meg.<br/>
                        A képzés próbált összpontosítani az alapok megismerésére, több fajta technológia 
                        gyors elsajátítására egy alapvető szinten. 
                        Megismerkedtünk az alacsonyabb szintű nyelekkel (C++, Assembly), az egységes leíró nyelvel,
                        alapvető kereső, rendező és egyéb algoritmusokkal, az Objektum Orientált Programozással, 
                        dokumentiációval, fejlesztési technikákkal, keretrendszerekkel, Mesterséges Intelligenciával, 
                        valamint többféle operációs rendszerrel.<br/>
                        Eddigi projektjeim elérhetőek a GitHub profilom alatt, technológiákra bontva, valamint a 
                        "Projektek" fül alatt demo oldalak.
                        </p>
                </div>
            </div>

        </div>
    );
}

export default FromMe;