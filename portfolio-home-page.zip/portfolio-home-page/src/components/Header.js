import HeaderItemList from "../elements/headeritemList";
import {headers} from "../datas/headers.js";

function Header() {
  return (
    <nav className="dt w-100 center bg-black-40 fixed z-max">
      <div className="dtc v-mid pa3">
        <a href="/" className="hover-white no-underline white-70 dib pa1 grow-large border-box">Honlap neve</a>
      </div>
      <HeaderItemList headers={headers}/>
    </nav>
  );
}

export default Header;