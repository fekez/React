import FromMe from "./FromMe";
import Projects from "./Projects";
import Technologies from "./Technologies";
import Welcome from "./Welcome";

function Content() {
    return (
        <div>
            <Welcome/>
            <FromMe/>
            <Technologies/>
            <Projects/>
        </div>
    );
}

export default Content;