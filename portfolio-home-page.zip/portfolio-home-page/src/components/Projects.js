import ProjectList from "../elements/projectList";
import { projects } from "../datas/projects";

function Projects() {
    return (
        <div id="projects" className="tc black w-100 ph5 pv5">
            <div className="w-100 mb4">
                <h2 className="white bg-black-80 br2 pa2 ph3 dib ma0 ">AZ EGYETEM ALATT ELKÉSZÜLT DEMO PROJEKTEK</h2>
            </div>
            <ProjectList projects={projects} />
        </div>
    );
}

export default Projects;