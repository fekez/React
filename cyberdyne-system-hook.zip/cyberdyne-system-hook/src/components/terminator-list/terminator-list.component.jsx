import React from "react";
import Terminator from "../terminator/terminator.component";

const TerminatorList = ({ models }) => {
  return (
    <div>
      {" "}
      {models.map((model) => {
        return (
          <Terminator
            key={model.id}
            name={model.name}
            serialNumber={model.phone}
            id={model.id}
          />
        );
      })}
    </div>
  );
};

export default TerminatorList;
